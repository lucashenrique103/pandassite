<?php
// gerar hash fixo para uma senha
echo password_hash("mase", PASSWORD_BCRYPT) . PHP_EOL;
?>
